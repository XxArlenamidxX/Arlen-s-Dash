#!/bin/bash

echo "Installing dependencies..."

# Install required packages
apt update
apt install -y zip unzip php-cli php apache2

# Setup script
mkdir -p /var/www/website/backups/recent-backups
cp backup_restore.sh /usr/local/bin/backup_restore.sh
chmod +x /usr/local/bin/backup_restore.sh

# Create API folder
mkdir -p /var/www/website/api
cp backup-handler.php /var/www/website/api/backup-handler.php

echo "Done. You can now use the backup system!"
