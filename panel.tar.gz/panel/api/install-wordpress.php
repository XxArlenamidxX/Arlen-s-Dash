<?php
$source = '/etc/arlenspanel/wordpress';
$destination = '/var/www/website';

function copyRecursive($src, $dst) {
    $dir = opendir($src);
    if (!is_dir($dst)) mkdir($dst, 0755, true);
    while(false !== ($file = readdir($dir))) {
        if ($file === '.' || $file === '..') continue;
        $srcPath = "$src/$file";
        $dstPath = "$dst/$file";
        if (is_dir($srcPath)) {
            copyRecursive($srcPath, $dstPath);
        } else {
            copy($srcPath, $dstPath);
        }
    }
    closedir($dir);
}

try {
    copyRecursive($source, $destination);
    echo "[✓] WordPress installed successfully to $destination.";
} catch (Exception $e) {
    http_response_code(500);
    echo "[✗] Failed: " . $e->getMessage();
}
?>
