<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit("Only POST allowed.");
}

$action = $_GET['action'] ?? '';
if (!in_array($action, ['backup', 'restore'])) {
  http_response_code(400);
  exit("Invalid action.");
}

$cmd = escapeshellcmd("/usr/local/bin/backup_restore.sh $action");
$output = shell_exec($cmd);
echo nl2br(htmlspecialchars($output));
?>
